export const SECRET:string = 'SECr3t';
export const connectionString:string = 'mongodb+srv://abhishek:1234@bidhubcuster.dwbxoue.mongodb.net/bidhub';
export const port:Number = 4242;