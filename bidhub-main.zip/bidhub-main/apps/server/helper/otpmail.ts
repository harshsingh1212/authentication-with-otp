const nodemailer = require("nodemailer");

// Create a transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'abhitiwari3010@gmail.com', // generated ethereal user
    pass: 'qoii dhsi hkzq yxte', // generated ethereal password
  },
});

// Send OTP mail function
async function sendOTPMail(userMail: string, otp: number): Promise<void> {
  // Send mail with defined transport object
  const info = await transporter.sendMail({
    from: '"BidHub" <abhinathtiwari1@gmail.com>', 
    to: userMail, 
    subject: 'One Time Password', 
    text: otp.toString(), // plain text body
    html: `
    <html>
    <head>
    <style>
      .email-container {
        max-width: 600px;
        margin: auto;
        padding: 20px;
        
      }
      .email-content {
        background-color: #f7f7f7;
        padding: 20px;
        border-radius: 5px;
        text-align: center;
      }
      .email-header {
        background-color: #FF6B00;
        color: white;
        padding: 10px;
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
      }
      .otp-code {
        font-size: 24px;
        margin: 20px 0;
        padding: 10px;
        border: 1px solid #ddd;
        display: inline-block;
        background-color: #fff;
      }
    </style>
    </head>
    <body>
    <div class="email-container">
      <div class="email-header">
        <h1>BidHub</h1>
      </div>
      <div class="email-content">
        <p>Hello,</p>
        <p>Your One-Time Password (OTP) for verification is:</p>
        <div class="otp-code">${otp}</div> 
      </div>
    </div>
    </body>
    </html>
    `, // html body
  });

  console.log('Message sent: %s', info.messageId);
}

export default sendOTPMail;
