import express, { Request, Response } from 'express';
import sendOTPMail from './otpmail';
const router = express.Router();
interface OTPStore {
  [key: string]: number;
}

const app = express();
app.use(express.json());

const otpStore: OTPStore = {};

router.post('/sendOtp', (req: Request, res: Response) => {
  console.log("here");
  const email = req.body.username;
  if (!email) {
    return res.status(400).send('Email is required.');
  }
  const otp: number = Math.floor(Math.random() * 1000) + 1;
  otpStore[email] = otp;
  sendOTPMail(email, otp);
  console.log(`OTP for ${email}: ${otp}`);

  res.send('OTP sent to email.');
});

router.post('/verify-otp', (req: Request, res: Response) => {
  const { email, otp } = req.body;
  if (!email || !otp) {
    return res.status(400).send('Email and OTP are required.');
  }
  const storedOtp = otpStore[email];
  if (otp == storedOtp) {
    delete otpStore[email];
    res.send('OTP verified successfully.');
  } else {
    console.log(otp);
    console.log("storedotp");
    console.log(storedOtp);
    res.status(400).send('Invalid OTP.');
  }
});

export default router;
