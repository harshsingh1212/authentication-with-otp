const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false, // Use `true` for port 465, `false` for all other ports
  auth: {
    user: "abhitiwari3010@gmail.com",
    pass: "qoii dhsi hkzq yxte",
  },

});

export async function soldMail(
  userMail: string,
  sellerMail: string | undefined,
  sellPrice: number,
  productName: string
): Promise<void> {
  // Define the recipients
  const recipients = sellerMail ? `${userMail}, ${sellerMail}` : userMail;

  // Define the HTML content for the receipt
  const htmlContent = `
    <div>
      <h1>Bid Receipt</h1>
      <p>Item was sold!!</p>
      <p><strong>Product Name:</strong> ${productName}</p>
      <p><strong>Sell Price:</strong> INR${sellPrice.toFixed(2)}</p>
      <p><strong>Buyer Mail:</strong> ${userMail}</p>
      <p><strong>Seller Mail:</strong> ${sellerMail}</p>
      <hr>
      <p>
      This is to inform you that biding ${productName} has been completed at a price of INR ${sellPrice.toFixed(2)}. to the user ${userMail} 
      </p>
      <p>This is a confirmation of the sale transaction. Please keep it for your records.</p>
    </div>
  `;

  // Send mail with defined transport object
  const info = await transporter.sendMail({
    from: '"BidHub" <abhinathtiwari1@gmail.com>', // sender address
    to: recipients, // list of receivers
    subject: "Product Sold ✔", // Subject line
    text: `Biding ${productName} has been completed at a price of INR ${sellPrice.toFixed(2)}. to the user ${userMail} `, // plain text body
    html: htmlContent, // html body
  });


  console.log("Message sent: %s", info.messageId);
  // Message sent: <d786aa62-4e0a-070a-47ed-0b0666549519@ethereal.email>
}

