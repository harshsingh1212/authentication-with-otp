// export const base_url = "https://bidhub.netlify.app/api";
export const base_url = "http://localhost:4242";