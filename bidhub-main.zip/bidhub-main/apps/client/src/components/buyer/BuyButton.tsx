function BuyButton(){
    return <>
    </>
}

export default BuyButton