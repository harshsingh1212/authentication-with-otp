export function VerticalLine(){

    return   <div className="hidden lg:inline-block"  style={{borderLeft:"1px solid grey",height:"70vh"}}>
    </div>
}
