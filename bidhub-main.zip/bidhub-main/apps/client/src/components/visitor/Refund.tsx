function Refund(){
    return <div className="bg-gray-700 h-screen">This is Refund Policy</div>
}

export default Refund;