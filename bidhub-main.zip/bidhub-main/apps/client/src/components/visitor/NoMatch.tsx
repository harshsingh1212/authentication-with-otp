// import React from "react";

function NoMatch(){
    return <>
    Nothing was here...
    </>
}

export default NoMatch;