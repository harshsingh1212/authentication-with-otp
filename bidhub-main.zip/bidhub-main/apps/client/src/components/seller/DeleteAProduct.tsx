function DeleteProduct(){
    return <></>
}

export default DeleteProduct;