function AcceptBidButton(){
    return <></>
}
export default AcceptBidButton;