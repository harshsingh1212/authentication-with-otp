module.exports = {
  extends: ["custom/react-internal"],
};
